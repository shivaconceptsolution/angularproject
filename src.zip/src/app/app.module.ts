import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdditionComponent } from './addition/addition.component';
import { FormsModule } from '@angular/forms';
import { MyformComponent } from './myform/myform.component';
import { RouterModule } from '@angular/router';
import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
const routes: Routes = [ 
  { path: '', component: HomeComponent }, // Home page route 
  { path: 'about', component: AboutComponent },
  { path: 'addition', component:AdditionComponent },
  { path: 'myform', component: MyformComponent } // About page route 
]; 
@NgModule({
  declarations: [
    AppComponent,
    AdditionComponent,
    MyformComponent,
    HomeComponent,
    AboutComponent,
    HeaderComponent,
    FooterComponent
   
  ],
  imports: [
    FormsModule,
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(routes) 
  ],
  providers: [
    provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
