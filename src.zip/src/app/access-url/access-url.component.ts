import { Component } from '@angular/core';
import { PostService } from '../post.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-access-url',
  templateUrl: './access-url.component.html',
  styleUrl: './access-url.component.css'
})
export class AccessUrlComponent {
  posts:any;
  postdata:any;
  
  constructor(private service:PostService,private router:Router) {}

  ngOnInit() {
   this.postdata=null;
    
}
findPosts()
{
  this.service.findPosts().subscribe(response => {
        this.postdata = response;
       // console.log(response);
      });
}
viewData()
{
  this.service.getPosts().subscribe(response => {
        this.posts = response;
        console.log(response);
      });
}
submitData()
{
  const dataToSend = {name:'shahshi'}; // Replace with your data
    this.service.addPosts(dataToSend).subscribe(
      (response) => {
        console.log('Post successful:', response);
        // Handle the response as needed
      },
      (error) => {
        console.error('Error:', error);
        // Handle errors
      }
    );
}
submitData1()
{
  const dataToSend = {rno:2,name:'OM SHANTI OM'}; // Replace with your data
    this.service.updatePosts(dataToSend).subscribe(
      (response) => {
        console.log('Edit successful:', response);
        // Handle the response as needed
      },
      (error) => {
        console.error('Error:', error);
        // Handle errors
      }
    );
}
submitData2()
{
 this.service.deletePosts(4).subscribe(
      (response) => {
        console.log('Delete successful:', response);
        // Handle the response as needed
      },
      (error) => {
        console.error('Error:', error);
        // Handle errors
      }
    );
}
submitData3()
{
  var id = 10
  this.router.navigate(['/addition',id]);
}
}
