import { SquarePipePipe } from './square-pipe.pipe';

describe('SquarePipePipe', () => {
  it('create an instance', () => {
    const pipe = new SquarePipePipe();
    expect(pipe).toBeTruthy();
  });
});
