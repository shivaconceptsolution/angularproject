import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  constructor() { }
  show() { 
    let ndate = new Date(); 
    return ndate; 
 }  
 mymoney()
 {
  return "4512333";
 }
}
