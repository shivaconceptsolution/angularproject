import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormvaliationComponent } from './formvaliation.component';

describe('FormvaliationComponent', () => {
  let component: FormvaliationComponent;
  let fixture: ComponentFixture<FormvaliationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FormvaliationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FormvaliationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
