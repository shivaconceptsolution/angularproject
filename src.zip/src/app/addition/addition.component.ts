import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-addition',
  templateUrl: './addition.component.html',
  styleUrl: './addition.component.css'
})
export class AdditionComponent {
  a:number=12
  b:number=2
  c:number=0
  param=null;
  data:number=0;
  courses = ['C', 'C++','DS', 'JAVA'];
  constructor(private activatedRoute: ActivatedRoute) {}
  ngOnInit() {
    // Subscribe to the route parameter changes
    this.activatedRoute.params.subscribe(params => {
      // Retrieve the 'id' parameter from the route
      this.data = +params['id']; // Convert to a number if needed
    });
  }
  add(event:any):void {
    this.param = event.target.value;
    if(this.param=="Addition")
    {
    this.c = this.a+this.b;
    }
    else if(this.param=="Substraction")
    {
      this.c = this.a-this.b;
    }
    else if(this.param=="Multiplication")
    {
      this.c = this.a*this.b;
    }
    else if(this.param=="Division")
    {
      this.c = this.a/this.b;
    }
    alert("hello"+this.a);
  }
}
