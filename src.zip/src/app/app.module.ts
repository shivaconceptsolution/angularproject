import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import {AsyncPipe} from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdditionComponent } from './addition/addition.component';
import { FormsModule,ReactiveFormsModule} from '@angular/forms';
  
import { MyformComponent } from './myform/myform.component';
import { RouterModule } from '@angular/router';
import { Routes, Router } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { provideHttpClient } from '@angular/common/http';
import { AccessUrlComponent } from './access-url/access-url.component';
import { PostService } from './post.service';
import { FormvaliationComponent } from './formvaliation/formvaliation.component';
import { ChangeTextDirective } from './change-text.directive';
import { SquarePipePipe } from './square-pipe.pipe';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSliderModule } from '@angular/material/slider';
import { MatButtonModule } from '@angular/material/button';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import { LocalStorageService } from 'ngx-webstorage';
const routes: Routes = [ 
  { path: '', component: HomeComponent }, // Home page route 
  { path: 'about', component: AboutComponent },
  { path: 'post', component: AccessUrlComponent},
  { path: 'addition/:id', component:AdditionComponent },
  { path: 'myform', component: MyformComponent } // About page route 
]; 
@NgModule({
  declarations: [
    AppComponent,
    AdditionComponent,
    MyformComponent,
    HomeComponent,
    AboutComponent,
    HeaderComponent,
    FooterComponent,
    AccessUrlComponent,
    FormvaliationComponent,
    ChangeTextDirective,
    SquarePipePipe
   
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatSlideToggleModule,
    MatSliderModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    AsyncPipe,
    
    RouterModule.forRoot(routes) 
  ],
  providers: [
    provideClientHydration(),
    provideHttpClient(),
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
