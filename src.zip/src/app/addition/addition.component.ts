import { Component } from '@angular/core';

@Component({
  selector: 'app-addition',
  templateUrl: './addition.component.html',
  styleUrl: './addition.component.css'
})
export class AdditionComponent {
  a:number=12
  b:number=2
  c:number=0
  param=null;
  courses = ['C', 'C++','DS', 'JAVA'];

  add(event:any):void {
    this.param = event.target.value;
    if(this.param=="Addition")
    {
    this.c = this.a+this.b;
    }
    else if(this.param=="Substraction")
    {
      this.c = this.a-this.b;
    }
    else if(this.param=="Multiplication")
    {
      this.c = this.a*this.b;
    }
    else if(this.param=="Division")
    {
      this.c = this.a/this.b;
    }
    alert("hello"+this.a);
  }
}
