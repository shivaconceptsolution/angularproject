import { Component,Input, OnChanges,OnDestroy,SimpleChanges } from '@angular/core';
import { MyserviceService } from '../myservice.service';
import { Observable, Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { LocalStorageService } from 'ngx-webstorage';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnDestroy  {
 // todaydate = new Date();
  //s;
  username: string = '';
  email: string = '';
  @Input() st: string | undefined;
  //curr;
  private intervalId: any;

  constructor() {
    // Example: Setting up an interval in the constructor
    this.intervalId = setInterval(() => {
      console.log('Interval is running...');
    }, 1000);
  }

  ngOnDestroy(): void {
    // Cleanup operations, such as clearing intervals, go here
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }

    console.log('Component destroyed');
  }
  ngOnInit()
  {
    console.log('OnInit')
  }
  ngOnChanges(changes: SimpleChanges):void
  {
    if(changes['st'])
    {
      this.st='onChanges';
    console.log('OnChanges')
    }
    
    
  }
  ngDoCheck(): void {
    // Custom change detection logic goes here
    console.log('ngDoCheck called');
  }
  ngAfterContentInit():void{
    console.log('ng Content intialize');
  }
  ngAfterContentChecked():void
  {
    console.log('ngafterContent Checked called');
  }
  
  updateUser(username: string): void {
    this.username = username;
  }

  updateEmail(email: string): void {
    this.email = email;
  }
  add()
  {
    
    
   // this.router.navigateByUrl('/home');
    this.st='btnClick';
  }
  /*constructor(private myser: MyserviceService) {
    this.s= this.myser.show()
    this.curr = this.myser.mymoney()
    }*/
}
