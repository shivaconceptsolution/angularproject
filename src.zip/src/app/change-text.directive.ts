import { Directive,ElementRef } from '@angular/core';

@Directive({
  selector: '[appChangeText]'
})
export class ChangeTextDirective {

  constructor(Element: ElementRef) {
  //  Element.nativeElement.innerText='welcome in shiva concept solution';
      Element.nativeElement.style.backgroundColor = 'yellow';
   }

}
